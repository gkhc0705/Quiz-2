#!/bin/python

import re
validIP1 = "192.168.2.1"
validIP2 = "200.8.233.27"
validIP3 = "1.1.1.1"

nonValidIP1 = "3.4.5"
nonValidIP2 = "4.5.6"
nonvalidIP3 = "7.8.9"

regex = "^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"

if  re.search(regex, sys.argv[3]):
    print sys.argv[3] + " is a valid ip address!"
else:
    print sys.argv[3] + " is not a valid ip address!"

if re.search(regex, validIP1):
    print validIP1 + " is a valid ip address!"
else:
    print validIP1 + " is not a valid ip address!"

if re.search(regex, validIP2):
    print validIP2 + " is a valid ip address!"
else:
    print validIP2 + " is not a valid ip address!"

if re.search(regex, validIP3):
    print validIP3 + " is a valid ip address!"
else:
    print validIP3 + " is not a valid ip address!"

if re.search(regex, nonValidIP1):
    print nonValidIP1 + " is a valid ip address!"
else:
    print nonValidIP1 + " is not a valid ip address!"

if re.search (regex, nonValidIP2):
    print nonValidIP2 + " is a valid ip address!"
else:
    print nonValidIP2 + " is not a valid ip address!"

if re.search (regex, nonValidIP3):
    print nonValidIP3 + " is a valid ip address!"
else:
    print nonValidIP3 + " is not a valid ip address!"


